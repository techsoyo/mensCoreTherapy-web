<section class="mm-productos page-wrap">
  <div class="container">
    <h1>Nuestros Productos</h1>
    <p>Catálogo de ejemplo:</p>
    <table class="mm-table">
      <thead>
        <tr><th>Producto</th><th>Precio</th><th>Descripción</th></tr>
      </thead>
      <tbody>
        <tr><td>Aceite Relajante 250ml</td><td>€19,90</td><td>Aceite base almendra con aroma cítrico.</td></tr>
        <tr><td>Bono 3 Sesiones</td><td>€120,00</td><td>Paquete ahorro para 3 masajes de 60min.</td></tr>
      </tbody>
    </table>
  </div>
</section>
