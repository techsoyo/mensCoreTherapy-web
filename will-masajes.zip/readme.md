la ruta correcta es C:\Users\kikko\Local Sites\will-masajes\app\public\wp-content\themes\masajista-masculino\

paleta colore:
Primario: #FF6C32 (naranja vibrante)
Primario hover: #D73D00 (naranja oscuro)
Secundario: #FF8C5F (naranja suave)
Secundario suave: #FFAC8C (naranja muy suave)
Fondo base: #FFEDE6 (crema cálido)
Fondo superficie: #FFCDB9 (melocotón suave)
Texto titulares: #240A00 (marrón muy oscuro)
Texto cuerpo: #3B1400 (marrón oscuro)
Texto secundario: #7D2400 (marrón medio)
Acento sombras: #AA3000 (rojo marrón)
Overlay: #FFE5D8 (crema rosado)